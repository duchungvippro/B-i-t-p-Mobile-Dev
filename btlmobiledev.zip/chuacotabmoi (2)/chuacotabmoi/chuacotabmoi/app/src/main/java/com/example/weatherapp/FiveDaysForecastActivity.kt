package com.example.weatherapp

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.weatherapp.databinding.ActivityFiveDaysForecastBinding

class FiveDaysForecastActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFiveDaysForecastBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFiveDaysForecastBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val forecastList = intent.getSerializableExtra("forecastList") as? ArrayList<DailyForecast>
        val cityName = intent.getStringExtra("city_name")
        val currentTemp = intent.getStringExtra("current_temp")

        if (forecastList == null) {
            Toast.makeText(this, "Không có dữ liệu dự báo thời tiết", Toast.LENGTH_SHORT).show()
            return
        }

        // Gán tên thành phố
        binding.tvLocation.text = cityName

        // Gán nhiệt độ hiện tại
        binding.tvCurrentTemp.text = currentTemp

        // Gợi ý hoạt động theo nhiệt độ
        val tempValue = currentTemp?.replace("°", "")?.toIntOrNull() ?: 0
        val activitySuggestions = suggestActivity(tempValue)
        val suggestionText = activitySuggestions.joinToString(separator = "\n") { "• $it" }
        binding.tvSuggestion.text = suggestionText

        // Thiết lập danh sách 5 ngày
        binding.recyclerViewFiveDays.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewFiveDays.adapter = FiveDaysAdapter(forecastList)

        // Nút quay lại
        binding.btnBack.setOnClickListener {
            finish()
        }
    }


    private fun suggestActivity(tempC: Int): List<String> {
        return when {
            tempC < 10 -> listOf(
                "Đọc sách trong nhà",
                "Uống trà nóng",
                "Xem phim",
                "Nghe nhạc thư giãn"
            )
            tempC in 10..20 -> listOf(
                "Đi dạo công viên",
                "Uống café với bạn bè",
                "Chụp ảnh ngoài trời",
                "Tản bộ cùng thú cưng"
            )
            tempC in 21..30 -> listOf(
                "Chơi thể thao ngoài trời",
                "Dã ngoại hoặc picnic",
                "Đi bơi",
                "Lướt ván/Chơi bóng chuyền bãi biển"
            )
            else -> listOf(
                "Ở trong phòng máy lạnh",
                "Uống nước mát và nghỉ ngơi",
                "Đi bơi hoặc công viên nước",
                "Tránh vận động mạnh ngoài trời"
            )
        }
    }
}
