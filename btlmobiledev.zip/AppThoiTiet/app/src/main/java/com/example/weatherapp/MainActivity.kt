package com.example.weatherapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.weatherapp.databinding.ActivityMainBinding
import com.google.firebase.auth.FirebaseAuth
import retrofit2.*
import retrofit2.converter.gson.GsonConverterFactory
import com.example.weatherapp.data.AppDatabase
import com.example.weatherapp.data.FavoriteCity
import kotlinx.coroutines.*


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var auth: FirebaseAuth
    private val apiKey = "d754023544590c6ced61ca8f5582dce3"
    private val fiveDaysForecastData = mutableListOf<DailyForecast>()
    private var currentSearchedCity: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val cityFromIntent = intent.getStringExtra("city_name")
        if (!cityFromIntent.isNullOrEmpty()) {
            binding.cityInput.setText(cityFromIntent)
            // Delay nhẹ để giao diện load xong rồi mới click
            binding.cityInput.post {
                binding.btnSearch.performClick()
            }
        }


        intent.getStringExtra("city_name")?.let { city ->
            binding.cityInput.setText(city)
            binding.btnSearch.performClick()
        }

        binding.btnFavorites.setOnClickListener {
            val intent = Intent(this, FavoriteCitiesActivity::class.java)
            startActivity(intent)
        }



        //binding.btnAddToFavorite.visibility = View.VISIBLE

        binding.btnAddToFavorite.setOnClickListener {
            if (currentSearchedCity.isNotEmpty()) {
                CoroutineScope(Dispatchers.IO).launch {
                    AppDatabase.getDatabase(this@MainActivity)
                        .favoriteCityDao()
                        .insert(FavoriteCity(currentSearchedCity))
                }
                Toast.makeText(this, "$currentSearchedCity đã được thêm vào yêu thích", Toast.LENGTH_SHORT).show()
            }
        }

        // Khởi tạo Firebase Auth
        auth = FirebaseAuth.getInstance()

        // Nếu chưa đăng nhập thì chuyển đến LoginActivity
        if (auth.currentUser == null) {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
            return
        }

        // Nút logout
        binding.btnLogout.setOnClickListener {
            auth.signOut()
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }


        val btnMenu = findViewById<ImageButton>(R.id.btnMenu)

        btnMenu.setOnClickListener {
            val popupMenu = PopupMenu(this, it)
            popupMenu.menuInflater.inflate(R.menu.menu_main, popupMenu.menu)

            popupMenu.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.menu_add_favorite -> {
                        // Gọi hàm thêm TP vào yêu thích (ví dụ bạn đã có btnAddToFavorite.performClick())
                        findViewById<Button>(R.id.btnAddToFavorite).performClick()
                        true
                    }
                    R.id.menu_favorites -> {
                        // Gọi nút xem danh sách yêu thích
                        findViewById<Button>(R.id.btnFavorites).performClick()
                        true
                    }
                    R.id.menu_logout -> {
                        // Gọi hàm logout (nếu đã có)
                        findViewById<Button>(R.id.btnLogout).performClick()
                        true
                    }
                    else -> false
                }
            }

            popupMenu.show()
        }




        val retrofit = Retrofit.Builder()
            .baseUrl("https://api.openweathermap.org/data/2.5/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service = retrofit.create(WeatherService::class.java)

        binding.recyclerHourly.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        showSearchUI(true)

        binding.btnSearch.setOnClickListener {
            val city = binding.cityInput.text.toString().trim()
            if (city.isEmpty()) {
                Toast.makeText(this, getString(R.string.enter_city), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val lang = resources.configuration.locales.get(0).language
            currentSearchedCity = city

            // Gọi API để lấy thông tin thời tiết
            service.getWeatherByCity(city, apiKey, lang = lang)
                .enqueue(object : Callback<WeatherResponse> {
                    override fun onResponse(
                        call: Call<WeatherResponse>,
                        response: Response<WeatherResponse>
                    ) {
                        if (response.isSuccessful && response.body() != null) {
                            val data = response.body()!!

                            // Cập nhật thông tin thời tiết hiện tại
                            binding.tvCity.text = data.name
                            binding.tvDescription.text = data.weather[0].description
                            binding.tvTemp.text = "${data.main.temp.toInt()}°"
                            binding.tvTempMax.text = "↑${data.main.tempMax.toInt()}°"
                            binding.tvTempMin.text = "↓${data.main.tempMin.toInt()}°"
                            binding.tvHumidity.text = "Humidity: ${data.main.humidity}%"
                            binding.tvWindDirection.text = "Wind: ${getWindDirection(data.wind.deg)}"

                            // Cập nhật hình nền theo thời tiết
                            setBackgroundByWeather(data.weather[0].description)
                            showSearchUI(false) // Ẩn UI tìm kiếm và hiển thị thông tin thời tiết

                            // Gọi API để lấy dự báo theo giờ (nếu cần)
                            service.getHourlyForecast(city, apiKey, lang = lang)
                                .enqueue(object : Callback<ForecastResponse> {
                                    override fun onResponse(
                                        call: Call<ForecastResponse>,
                                        response: Response<ForecastResponse>
                                    ) {
                                        if (response.isSuccessful) {
                                            val forecastList = response.body()?.list?.take(5) ?: return
                                            val adapter = HourlyAdapter(forecastList)
                                            binding.recyclerHourly.adapter = adapter
                                        }
                                    }

                                    override fun onFailure(call: Call<ForecastResponse>, t: Throwable) {
                                        Log.e("FORECAST", "Error loading hourly forecast", t)
                                    }
                                })

                            // Bật nút để chuyển sang màn hình 5 ngày (nếu cần)
                            binding.btnFiveDay.setOnClickListener {
                                if (fiveDaysForecastData.isNotEmpty()) {
                                    val intent = Intent(this@MainActivity, FiveDaysForecastActivity::class.java)
                                    intent.putExtra("forecastList", ArrayList(fiveDaysForecastData))
                                    intent.putExtra("city_name", currentSearchedCity)
                                    intent.putExtra("current_temp", binding.tvTemp.text.toString())

                                    startActivity(intent)
                                } else {
                                    Toast.makeText(this@MainActivity, getString(R.string.city_not_found), Toast.LENGTH_SHORT).show()
                                }
                            }

                            loadFiveDayForecast(city)
                        } else {
                            Toast.makeText(this@MainActivity, getString(R.string.city_not_found), Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: Call<WeatherResponse>, t: Throwable) {
                        Log.e("WEATHER_API_ERROR", "Failed API call", t)
                        Toast.makeText(this@MainActivity, getString(R.string.api_error), Toast.LENGTH_SHORT).show()
                    }
                })
        }




        binding.btnAddCity.setOnClickListener {
            showSearchUI(true)
            binding.cityInput.setText("")
        }
    }

    private fun getWindDirection(degrees: Int): String {
        return when (degrees) {
            in 0..22 -> "N" // Bắc
            in 23..67 -> "NE" // Đông Bắc
            in 68..112 -> "E" // Đông
            in 113..157 -> "SE" // Đông Nam
            in 158..202 -> "S" // Nam
            in 203..247 -> "SW" // Tây Nam
            in 248..292 -> "W" // Tây
            in 293..337 -> "NW" // Tây Bắc
            in 338..360 -> "N" // Bắc
            else -> "Unknown"
        }
    }


    private fun showSearchUI(show: Boolean) {
        // Ẩn giao diện tìm kiếm khi đã có kết quả
        binding.cityInput.visibility = if (show) View.VISIBLE else View.GONE
        binding.btnSearch.visibility = if (show) View.VISIBLE else View.GONE

        // Chỉ hiển thị thông tin thời tiết khi đã có kết quả
        binding.tvCity.visibility = if (!show) View.VISIBLE else View.GONE
        binding.tvDescription.visibility = if (!show) View.VISIBLE else View.GONE
        binding.tvTemp.visibility = if (!show) View.VISIBLE else View.GONE
        binding.tvTempMax.visibility = if (!show) View.VISIBLE else View.GONE
        binding.tvTempMin.visibility = if (!show) View.VISIBLE else View.GONE

        binding.hourlyContainer.visibility = if (!show) View.VISIBLE else View.GONE
        binding.btnAddCity.visibility = if (!show) View.VISIBLE else View.GONE
        binding.btnMenu.visibility =  if (!show) View.VISIBLE else View.GONE

        binding.iconWind.visibility = if (!show) View.VISIBLE else View.GONE
        binding.iconHumidity.visibility = if (!show) View.VISIBLE else View.GONE
        binding.tvHumidity.visibility = if (!show) View.VISIBLE else View.GONE
        binding.tvWindDirection.visibility = if (!show) View.VISIBLE else View.GONE
    }



    private fun setBackgroundByWeather(description: String) {
        val desc = description.lowercase()
        val bgRes = when {
            "clear" in desc || "sun" in desc || "nắng" in desc -> R.drawable.bg_day
            "rain" in desc || "drizzle" in desc || "mưa" in desc -> R.drawable.bg_rain
            "cloud" in desc || "mây" in desc -> R.drawable.bg_clouds
            else -> R.drawable.bg_night
        }
        binding.bgImage.setImageResource(bgRes)
    }

    private fun loadFiveDayForecast(city: String) {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://api.openweathermap.org/data/2.5/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service = retrofit.create(WeatherService::class.java)
        val lang = resources.configuration.locales.get(0).language

        service.getFiveDayForecast(city, apiKey, lang = lang).enqueue(object : Callback<ForecastResponse> {
            override fun onResponse(call: Call<ForecastResponse>, response: Response<ForecastResponse>) {
                if (response.isSuccessful && response.body() != null) {
                    val allForecasts = response.body()!!.list

                    val dailyList = mutableListOf<DailyForecast>()
                    for (item in allForecasts) {
                        val date = item.dt_txt.substring(0, 10)
                        if (dailyList.none { it.date == date } && dailyList.size < 5) {
                            dailyList.add(
                                DailyForecast(
                                    date = date,
                                    temp = item.main.temp,
                                    icon = item.weather[0].icon
                                )
                            )
                        }
                    }

                    fiveDaysForecastData.clear()
                    fiveDaysForecastData.addAll(dailyList)
                }
            }

            override fun onFailure(call: Call<ForecastResponse>, t: Throwable) {
                Log.e("FIVEDAY", "Error loading 5 day forecast", t)
            }
        })
    }

    }

