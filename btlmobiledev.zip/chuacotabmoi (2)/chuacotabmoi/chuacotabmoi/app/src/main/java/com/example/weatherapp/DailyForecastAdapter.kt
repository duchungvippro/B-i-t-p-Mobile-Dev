package com.example.weatherapp

import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide

class DailyForecastAdapter(private val list: List<DailyForecast>) :
    RecyclerView.Adapter<DailyForecastAdapter.DailyViewHolder>() {

    class DailyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val date = view.findViewById<TextView>(R.id.tvDate)
        val temp = view.findViewById<TextView>(R.id.tvTemp)
        val icon = view.findViewById<ImageView>(R.id.imgWeather)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DailyViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_hourly, parent, false)
        return DailyViewHolder(view)
    }

    override fun onBindViewHolder(holder: DailyViewHolder, position: Int) {
        val item = list[position]
        holder.date.text = item.date
        holder.temp.text = "${item.temp.toInt()}°C"

        // Sử dụng Glide để tải icon từ OpenWeatherMap
        val iconRes = getIconResource(item.icon)
        holder.icon.setImageResource(iconRes)

    }

    // Thêm hàm này trong DailyForecastAdapter.kt
    private fun getIconResource(icon: String): Int {
        return when (icon) {
            "01d" -> R.drawable.ic_sun   // Icon trời nắng ban ngày
            "01n" -> R.drawable.ic_sun // Icon trời nắng ban đêm
            "02d" -> R.drawable.ic_few_clouds_day  // Icon ít mây ban ngày
            "02n" -> R.drawable.ic_cloud // Icon ít mây ban đêm
            "03d", "03n" -> R.drawable.ic_cloud // Icon mây rải rác
            "04d", "04n" -> R.drawable.ic_cloud // Icon mây phủ
            "09d", "09n" -> R.drawable.ic_rain  // Icon mưa
            "10d", "10n" -> R.drawable.ic_rain  // Icon mưa
            "11d", "11n" -> R.drawable.ic_storm // Icon bão
            "13d", "13n" -> R.drawable.ic_snow // Icon tuyết

            else -> R.drawable.ic_sun // Icon mặc định nếu không có match
        }
    }

    override fun getItemCount() = list.size
}


