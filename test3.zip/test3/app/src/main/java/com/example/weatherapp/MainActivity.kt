package com.example.weatherapp

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.weatherapp.databinding.ActivityMainBinding
import retrofit2.*
import retrofit2.converter.gson.GsonConverterFactory
import java.util.Calendar

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val apiKey = "d754023544590c6ced61ca8f5582dce3"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        showSearchUI(true)
        setBackgroundByTime()

        val retrofit = Retrofit.Builder()
            .baseUrl("https://api.openweathermap.org/data/2.5/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val service = retrofit.create(WeatherService::class.java)

        binding.btnSearch.setOnClickListener {
            val city = binding.cityInput.text.toString().trim()
            if (city.isEmpty()) {
                Toast.makeText(this, getString(R.string.enter_city), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val lang = resources.configuration.locales.get(0).language
            service.getWeatherByCity(city, apiKey, lang = lang)
                .enqueue(object : Callback<WeatherResponse> {
                    override fun onResponse(
                        call: Call<WeatherResponse>,
                        response: Response<WeatherResponse>
                    ) {
                        if (response.isSuccessful && response.body() != null) {
                            val data = response.body()!!

                            binding.tvCity.text = data.name
                            binding.tvDescription.text = data.weather[0].description
                            binding.tvTemp.text = "${data.main.temp.toInt()}°"
                            binding.tvTempMax.text = "↑${data.main.tempMax.toInt()}°"
                            binding.tvTempMin.text = "↓${data.main.tempMin.toInt()}°"

                            showSearchUI(false)
                        } else {
                            Toast.makeText(
                                this@MainActivity,
                                getString(R.string.city_not_found),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    override fun onFailure(call: Call<WeatherResponse>, t: Throwable) {
                        Log.e("WEATHER_API_ERROR", "Failed API call", t)
                        Toast.makeText(
                            this@MainActivity,
                            getString(R.string.api_error),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                })
        }

        binding.btnAddCity.setOnClickListener {
            showSearchUI(true)
            binding.cityInput.setText("")
        }
    }

    private fun showSearchUI(show: Boolean) {
        binding.cityInput.visibility = if (show) View.VISIBLE else View.GONE
        binding.btnSearch.visibility = if (show) View.VISIBLE else View.GONE

        binding.tvCity.visibility = if (show) View.GONE else View.VISIBLE
        binding.tvDescription.visibility = if (show) View.GONE else View.VISIBLE
        binding.tvTemp.visibility = if (show) View.GONE else View.VISIBLE
        binding.tvTempMax.visibility = if (show) View.GONE else View.VISIBLE
        binding.tvTempMin.visibility = if (show) View.GONE else View.VISIBLE

        binding.hourlyContainer.visibility = if (show) View.GONE else View.VISIBLE
        binding.btnAddCity.visibility = if (show) View.GONE else View.VISIBLE

        // 👇 Thêm điều kiện ẩn/hiện biểu tượng gió và độ ẩm
        binding.iconWind.visibility = if (show) View.GONE else View.VISIBLE
        binding.iconHumidity.visibility = if (show) View.GONE else View.VISIBLE
    }

    private fun setBackgroundByTime() {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val bgRes = if (hour in 6..17) R.drawable.bg_day else R.drawable.bg_night
        binding.bgImage.setImageResource(bgRes)
    }
}
