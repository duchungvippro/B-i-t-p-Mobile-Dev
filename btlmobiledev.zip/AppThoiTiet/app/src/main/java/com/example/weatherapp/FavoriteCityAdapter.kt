package com.example.weatherapp

import android.view.*
import android.widget.TextView
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherapp.data.FavoriteCity

class FavoriteCityAdapter(
    private val cities: List<FavoriteCity>,
    private val onClick: (FavoriteCity) -> Unit,
    private val onDeleteClick: (FavoriteCity) -> Unit // Thêm callback để xử lý xóa
) : RecyclerView.Adapter<FavoriteCityAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvCityName)
        val ivIcon: ImageView = view.findViewById(R.id.ivCityIcon) // Khai báo ImageView cho icon thành phố
        val btnDelete: ImageView = view.findViewById(R.id.btnDeleteCity) // Khai báo ImageView cho nút xóa

        init {
            view.setOnClickListener {
                onClick(cities[adapterPosition])
            }
            btnDelete.setOnClickListener {
                onDeleteClick(cities[adapterPosition]) // Xử lý xóa khi nhấn nút xóa
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_favorite_city, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount() = cities.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val city = cities[position]
        holder.tvName.text = city.cityName
        holder.ivIcon.setImageResource(R.drawable.ic_city) // Dùng icon chung cho tất cả các thành phố
    }
}
