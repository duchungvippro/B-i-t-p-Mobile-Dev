package com.example.weatherapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.Toast
import android.widget.ImageView
import android.widget.EditText
import android.view.MotionEvent
import androidx.appcompat.app.AppCompatActivity
import com.example.weatherapp.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    private lateinit var auth: FirebaseAuth
    private var isPasswordVisible = false  // Đưa biến này ra ngoài onCreate

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()

        binding.etRegisterPassword.setOnTouchListener { _, event ->
            val drawableEnd = binding.etRegisterPassword.compoundDrawables[2]
            if (event.action == MotionEvent.ACTION_UP && drawableEnd != null) {
                val x = event.x.toInt()
                if (x >= binding.etRegisterPassword.width - binding.etRegisterPassword.paddingRight - drawableEnd.intrinsicWidth) {
                    isPasswordVisible = !isPasswordVisible
                    if (isPasswordVisible) {
                        // Hiển thị mật khẩu
                        binding.etRegisterPassword.inputType = InputType.TYPE_CLASS_TEXT
                        binding.etRegisterPassword.setCompoundDrawablesWithIntrinsicBounds(
                            null, null, getDrawable(R.drawable.eye), null
                        )
                    } else {
                        // Ẩn mật khẩu
                        binding.etRegisterPassword.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                        binding.etRegisterPassword.setCompoundDrawablesWithIntrinsicBounds(
                            null, null, getDrawable(R.drawable.eyeoff), null
                        )
                    }
                    // Đặt lại con trỏ ở cuối nội dung
                    binding.etRegisterPassword.setSelection(binding.etRegisterPassword.text.length)
                    return@setOnTouchListener true
                }
            }
            false
        }

        binding.btnDoRegister.setOnClickListener {
            val email = binding.etRegisterEmail.text.toString().trim()
            val password = binding.etRegisterPassword.text.toString().trim()

            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                binding.etRegisterEmail.error = "Email không hợp lệ"
                return@setOnClickListener
            }

            if (password.length < 6) {
                binding.etRegisterPassword.error = "Mật khẩu phải từ 6 ký tự"
                return@setOnClickListener
            }

            // Đăng ký tài khoản
            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "Đăng ký thành công", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this, LoginActivity::class.java))
                        finish()
                    } else {
                        Toast.makeText(this, "Đăng ký thất bại: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
        }

        // Xử lý khi bấm vào dòng "Đã có tài khoản? Đăng nhập tại đây"
        binding.tvGoToLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
