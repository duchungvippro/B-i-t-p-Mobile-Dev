    package com.example.weatherapp

    import java.io.Serializable

    data class DailyForecast(
        val date: String,
        val temp: Float,
        val icon: String
    ) : Serializable
