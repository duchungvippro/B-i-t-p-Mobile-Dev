package com.example.weatherapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherapp.data.AppDatabase
import com.example.weatherapp.data.FavoriteCity
import kotlinx.coroutines.*

class FavoriteCitiesActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: FavoriteCityAdapter
    private lateinit var cities: MutableList<FavoriteCity> // Danh sách thành phố yêu thích

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favorite_cities)

        recyclerView = findViewById(R.id.recyclerFavoriteCities)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Lấy danh sách thành phố yêu thích từ database trong background thread
        CoroutineScope(Dispatchers.IO).launch {
            cities = AppDatabase.getDatabase(this@FavoriteCitiesActivity).favoriteCityDao().getAll().toMutableList()

            // Cập nhật RecyclerView trong main thread
            withContext(Dispatchers.Main) {
                adapter = FavoriteCityAdapter(cities, { city ->
                    // Khi nhấn vào thành phố yêu thích, quay lại MainActivity với thông tin thành phố
                    val intent = Intent(this@FavoriteCitiesActivity, MainActivity::class.java)
                    intent.putExtra("city_name", city.cityName)
                    startActivity(intent)
                }, { city ->
                    // Xử lý xóa thành phố khi nhấn nút xóa
                    deleteCity(city)
                })
                recyclerView.adapter = adapter
            }
        }
    }

    private fun deleteCity(city: FavoriteCity) {
        // Xóa thành phố khỏi database
        CoroutineScope(Dispatchers.IO).launch {
            AppDatabase.getDatabase(this@FavoriteCitiesActivity).favoriteCityDao().delete(city)

            // Cập nhật lại danh sách thành phố yêu thích
            withContext(Dispatchers.Main) {
                cities.remove(city)
                adapter.notifyDataSetChanged() // Cập nhật RecyclerView
            }
        }
    }

    // Thêm thành phố yêu thích mới (ví dụ từ một nút hoặc hộp thoại)
    private fun addCity(cityName: String) {
        val newCity = FavoriteCity(cityName)

        // Thêm thành phố vào database
        CoroutineScope(Dispatchers.IO).launch {
            AppDatabase.getDatabase(this@FavoriteCitiesActivity).favoriteCityDao().insert(newCity)

            // Cập nhật lại danh sách thành phố yêu thích
            withContext(Dispatchers.Main) {
                cities.add(newCity)
                adapter.notifyItemInserted(cities.size - 1) // Cập nhật RecyclerView
            }
        }
    }
}
