package com.example.weatherapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FiveDaysAdapter(private val forecastList: List<DailyForecast>) :
    RecyclerView.Adapter<FiveDaysAdapter.ForecastViewHolder>() {

    inner class ForecastViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val dateText: TextView = view.findViewById(R.id.tvDate)
        val tempText: TextView = view.findViewById(R.id.tvTemp)
        val iconImage: ImageView = view.findViewById(R.id.imgWeather)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ForecastViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_forecast, parent, false)
        return ForecastViewHolder(view)
    }

    override fun onBindViewHolder(holder: ForecastViewHolder, position: Int) {
        val forecast = forecastList[position]
        holder.dateText.text = forecast.date
        holder.tempText.text = "${forecast.temp.toInt()}°C"

        val iconRes = getIconResource(forecast.icon)
        holder.iconImage.setImageResource(iconRes)
    }

    private fun getIconResource(icon: String): Int {
        return when (icon) {
            "01d" -> R.drawable.ic_sun
            "01n" -> R.drawable.ic_sun
            "02d" -> R.drawable.ic_few_clouds_day
            "02n" -> R.drawable.ic_cloud
            "03d", "03n" -> R.drawable.ic_cloud
            "04d", "04n" -> R.drawable.ic_cloud
            "09d", "09n" -> R.drawable.ic_rain
            "10d", "10n" -> R.drawable.ic_rain
            "11d", "11n" -> R.drawable.ic_storm
            "13d", "13n" -> R.drawable.ic_snow
            else -> R.drawable.ic_sun
        }
    }


    override fun getItemCount() = forecastList.size
}
