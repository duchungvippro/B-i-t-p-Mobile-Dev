package com.example.weatherapp

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.weatherapp.databinding.ActivityFiveDaysForecastBinding
import java.util.Calendar

class FiveDaysForecastActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFiveDaysForecastBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFiveDaysForecastBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val forecastList = intent.getSerializableExtra("forecastList") as? ArrayList<DailyForecast>
        val cityName = intent.getStringExtra("city_name")
        val currentTemp = intent.getStringExtra("current_temp")

        if (forecastList == null) {
            Toast.makeText(this, "Không có dữ liệu dự báo thời tiết", Toast.LENGTH_SHORT).show()
            return
        }

        // ✅ Đổi background theo thời tiết
        val weatherIcon = forecastList[0].icon
        val backgroundRes = when (weatherIcon) {
            "01d" -> R.drawable.bg_day
            "01n" -> R.drawable.bg_night
            "02d", "02n" -> R.drawable.bg_clouds
            "03d", "03n", "04d", "04n" -> R.drawable.bg_clouds
            "09d", "09n", "10d", "10n" -> R.drawable.bg_rain
            "11d", "11n" -> R.drawable.bg_day
            "13d", "13n" -> R.drawable.bg_night
            else -> R.drawable.bg_day
        }
        binding.root.setBackgroundResource(backgroundRes)

        // Gán tên thành phố
        binding.tvLocation.text = cityName

        // Gán nhiệt độ hiện tại
        binding.tvCurrentTemp.text = currentTemp

        // Gợi ý hoạt động theo nhiệt độ
        val tempValue = currentTemp?.replace("°", "")?.toIntOrNull() ?: 0
        val activitySuggestions = suggestActivity(tempValue)
        val suggestionText = activitySuggestions.joinToString(separator = "\n") { "• $it" }
        binding.tvSuggestion.text = suggestionText

        // Thiết lập danh sách 5 ngày
        binding.recyclerViewFiveDays.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewFiveDays.adapter = FiveDaysAdapter(forecastList)

        // Nút quay lại
        binding.btnBack.setOnClickListener {
            finish()
        }
    }

    private fun suggestActivity(tempC: Int): List<String> {
        val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val isDaytime = currentHour in 6..18

        return when {
            tempC < 10 -> {
                if (isDaytime) {
                    listOf(
                        "Đi cà phê với bạn bè",
                        "Dạo phố",
                        "Chụp ảnh ngoài trời"
                    )
                } else {
                    listOf(
                        "Đọc sách trong nhà",
                        "Uống trà nóng",
                        "Xem phim",
                        "Nghe nhạc thư giãn"
                    )
                }
            }

            tempC in 10..20 -> {
                if (isDaytime) {
                    listOf(
                        "Đi dạo công viên ",
                        "Uống café với bạn bè",
                        "Chụp ảnh ngoài trời",
                        "Tản bộ cùng thú cưng"
                    )
                } else {
                    listOf(
                        "Đi dạo dưới ánh đèn đường",
                        "Ngồi quán cà phê ngoài trời",
                        "Thư giãn tại nhà với âm nhạc"
                    )
                }
            }

            tempC in 21..30 -> {
                if (isDaytime) {
                    listOf(
                        "Chơi thể thao ngoài trời",
                        "Dã ngoại hoặc picnic",
                        "Đi bơi",
                        "Lướt ván/Chơi bóng chuyền bãi biển"
                    )
                } else {
                    listOf(
                        "Xem phim ngoài trời",
                        "Tham gia các hoạt động vui chơi nhẹ nhàng"
                    )
                }
            }

            else -> {
                if (isDaytime) {
                    listOf(
                        "Ở trong phòng máy lạnh",
                        "Đi bơi hoặc công viên nước",
                        "Tránh vận động mạnh ngoài trời"
                    )
                } else {
                    listOf(
                        "Nghỉ ngơi trong phòng máy lạnh",
                        "Uống nước mát và thư giãn"
                    )
                }
            }
        }
    }
}
