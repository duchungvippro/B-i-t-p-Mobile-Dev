package com.example.weatherapp.data

import androidx.room.*

@Dao
interface FavoriteCityDao {

    // Thêm hoặc cập nhật thành phố yêu thích
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(city: FavoriteCity)

    // Lấy tất cả thành phố yêu thích
    @Query("SELECT * FROM favorite_cities")
    suspend fun getAll(): List<FavoriteCity>

    // Xóa thành phố yêu thích
    @Delete
    suspend fun delete(city: FavoriteCity)
}
