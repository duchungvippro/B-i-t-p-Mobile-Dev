package com.example.weatherapp

data class ForecastResponse(
    val list: List<ForecastItem>
)

data class ForecastItem(
    val dt_txt: String,
    val main: ForecastMain,
    val weather: List<HourlyWeather> // ✅ Dùng HourlyWeather, không dùng Weather trùng
)

data class ForecastMain(
    val temp: Float
)

data class HourlyWeather(
    val description: String,
    val icon: String
)
