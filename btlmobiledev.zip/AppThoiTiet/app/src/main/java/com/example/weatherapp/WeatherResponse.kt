package com.example.weatherapp

import com.google.gson.annotations.SerializedName

data class WeatherResponse(
    val name: String,
    val weather: List<Weather>,
    val main: Main,
    val wind: Wind
)

data class Weather(
    val main: String, // ví dụ: "Clouds", "Rain"
    val description: String // ví dụ: "overcast clouds", "light rain"
)

data class Main(
    val temp: Float,

    @SerializedName("temp_min")
    val tempMin: Float,  // Nhiệt độ tối thiểu

    @SerializedName("temp_max")
    val tempMax: Float,  // Nhiệt độ tối đa

    val humidity: Int
)

data class Wind(
    val speed: Float,
    val deg: Int
)

