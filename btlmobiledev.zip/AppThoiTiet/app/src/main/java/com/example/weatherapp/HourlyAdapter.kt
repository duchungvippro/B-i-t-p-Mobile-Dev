package com.example.weatherapp

import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView

class HourlyAdapter(private val list: List<ForecastItem>) :
    RecyclerView.Adapter<HourlyAdapter.HourlyViewHolder>() {

    class HourlyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvDate: TextView = view.findViewById(R.id.tvDate)
        val tvTime: TextView = view.findViewById(R.id.tvTime)
        val tvTemp: TextView = view.findViewById(R.id.tvTemp)
        val imgWeather: ImageView = view.findViewById(R.id.imgWeather)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HourlyViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_hourly, parent, false)
        return HourlyViewHolder(view)
    }

    override fun onBindViewHolder(holder: HourlyViewHolder, position: Int) {
        val item = list[position]

        // Format lại thời gian
        val dateTime = item.dt_txt // "2025-04-06 06:00:00"
        val parts = dateTime.split(" ")
        val date = parts.getOrNull(0) ?: ""
        val time = parts.getOrNull(1)?.substring(0, 5) ?: ""

        holder.tvDate.text = date
        holder.tvTime.text = time
        holder.tvTemp.text = "${item.main.temp.toInt()}°C"

        // TODO: Load icon thời tiết (sau này dùng Glide/Picasso)
        holder.imgWeather.setImageResource(R.drawable.ic_cloud) // Tạm dùng ảnh mặc định
    }

    override fun getItemCount(): Int = list.size
}
